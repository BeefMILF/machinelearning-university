N_max = 1e4;
x = rand(N_max,1);
a0 = -0.3;
a1 = 0.5;
a2 = 0.4;
s = 0.2;
alpha = 2;
beta = (1/s)^2;
t = a0 + a1 * x + a2 * x.^2;
t = t + normrnd(0,s,N_max,1);

Phi = zeros(N_max,3);
Phi(:,1) = 1;
Phi(:,2) = x;
Phi(:,3) = x.^2;

fig1 = figure;
fig2 = figure;
figs = {fig1, fig2};
points = 1e2+1;
params = linspace(-1,1,points);
[gridA, gridB] = meshgrid(params,params); 

samples = [1,10,100,N_max];
for n = 1:size(samples,2)
    N = samples(n);
    Phi2 = Phi(1:N,:);
    t2 = t(1:N);
    S_N = inv(eye(3)/alpha + beta * (Phi2'*Phi2));
    m_N = beta * S_N * (Phi2' * t2);
    
    weight_combs = [gridA(:) gridB(:)];
    
    % integrate out w2 by dopping third component (property of normal distribution)
    p_w0w1 = mvnpdf(weight_combs,m_N([1 2])',S_N([1 2],[1 2]));
    p_w0w1 = reshape(p_w0w1,points,points);
    
    % integrate out w0 by dopping first component (property of normal distribution)
    p_w1w2 = mvnpdf(weight_combs,m_N([2 3])',S_N([2 3],[2 3]));
    p_w1w2 = reshape(p_w1w2,points,points);

    % for (w0,w1) likelihood plot: choose w2 = a2 plane
    y = [weight_combs a2+zeros(points^2,1)] * Phi2(end,:)';
    log_likelihood = 0.5*beta*(t2(end)-y).^2;
    log_likelihood = log_likelihood / max(log_likelihood);
    likelihood = exp(-log_likelihood);
    likelihood = reshape(likelihood,points,points);
    
    set(0,'CurrentFigure',fig1)
    subplot(size(samples,2)+1,3,3*n+1)
    imagesc([-1 1],[-1 1],likelihood)   
    xlabel('\it w_0')
    ylabel('\it w_1')
    
    % for (w1,w2) likelihood plot: choose w0 = a0 plane
    y = [a0+zeros(points^2,1) weight_combs] * Phi2(end,:)';
    log_likelihood = 0.5*beta*(t2(end)-y).^2;
    log_likelihood = log_likelihood / max(log_likelihood);
    likelihood = exp(-log_likelihood);
    likelihood = reshape(likelihood,points,points);
    
    set(0,'CurrentFigure',fig2)
    subplot(size(samples,2)+1,3,3*n+1)
    imagesc([-1 1],[-1 1],likelihood)   
    xlabel('\it w_1')
    ylabel('\it w_2')
    
    set(0,'CurrentFigure',fig1)
    subplot(size(samples,2)+1,3,3*n+2)
    imagesc([-1 1],[-1 1],p_w0w1)   % (w0,w1) plane
    hold on
    scatter(a0,a1,'r+')
    xlabel('\it w_0')
    ylabel('\it w_1')
    
    set(0,'CurrentFigure',fig2)
    subplot(size(samples,2)+1,3,3*n+2)
    imagesc([-1 1],[-1 1],p_w1w2)   % (w1,w2) plane
    hold on
    scatter(a1,a2,'r+')
    xlabel('\it w_1')
    ylabel('\it w_2')
    
    % draw samples from posterior and show data points (x_n,t_n)
    curves = mvnrnd(m_N',S_N,10);
    for k = 1:2   
        set(0,'CurrentFigure',figs{k})
        subplot(size(samples,2)+1,3,3*n+3)
        scatter(x(1:N),t(1:N))
        hold on
        for j = 1:10
            plot(linspace(0,1), curves(j,1) + curves(j,2) * linspace(0,1) ...
                                  + curves(j,3) * linspace(0,1).^2)
        end
        hold off
        xlabel('\it x')
        ylabel('\it y')
    end
end


% plot prior
m_0 = zeros(3,1);
S_0 = eye(3) / alpha;
weight_combs = [gridA(:) gridB(:)]; 
p_w0w1 = mvnpdf(weight_combs,m_0([1 2])',S_0([1 2],[1 2]));
p_w0w1 = reshape(p_w0w1,points,points);
p_w1w2 = mvnpdf(weight_combs,m_0([2 3])',S_0([2 3],[2 3]));
p_w1w2 = reshape(p_w1w2,points,points);

set(0,'CurrentFigure',fig1)
subplot(size(samples,2)+1,3,2)
imagesc([-1 1],[-1 1],p_w0w1)
hold on
scatter(a0,a1,'r+')
xlabel('\it w_0')
ylabel('\it w_1')

set(0,'CurrentFigure',fig2)
subplot(size(samples,2)+1,3,2)
imagesc([-1 1],[-1 1],p_w1w2)
hold on
scatter(a1,a2,'r+')
xlabel('\it w_1')
ylabel('\it w_2')

% draw samples from prior
curves = mvnrnd(m_0',S_0,10);
for k = 1:2
    set(0,'CurrentFigure',figs{k})
    subplot(size(samples,2)+1,3,3)
    hold on
    for j = 1:10
        plot(linspace(0,1), curves(j,1) + curves(j,2) * linspace(0,1) ...
                              + curves(j,3) * linspace(0,1).^2)
    end
    hold off
    xlabel('\it x')
    ylabel('\it y')
    
    set(gcf,'PaperPositionMode', 'manual', ...
        'PaperUnits','centimeters', ...
        'Paperposition',[1 1 18 25])

    print(figs{k}, '-dpdf', sprintf('bayesian_quadratic_%d.pdf',k),'-r600');
end
