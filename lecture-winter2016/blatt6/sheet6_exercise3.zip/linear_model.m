N_max = 1000;
x = rand(N_max,1);
a0 = -0.3;
a1 = 0.5;
s = 0.2;
alpha = 2;
beta = (1/s)^2;
t = a0 + a1 * x;
t = t + normrnd(0,s,N_max,1);

Phi = zeros(N_max,2);
Phi(:,1) = 1;
Phi(:,2) = x;

figure;
points = 1e2+1;
params = linspace(-1,1,points);
[gridA, gridB] = meshgrid(params,params); 

samples = [1,10,100,N_max];
for n = 1:size(samples,2)
    N = samples(n);
    Phi2 = Phi(1:N,:);
    t2 = t(1:N);
    S_N = inv(eye(2)/alpha + beta * (Phi2'*Phi2));
    m_N = beta * S_N * (Phi2' * t2);
    
    weight_combs = [gridA(:) gridB(:)]; 
    p = mvnpdf(weight_combs,m_N',S_N);
    p = reshape(p,points,points);

    y = weight_combs * Phi2(end,:)';
    log_likelihood = 0.5*beta*(t2(end)-y).^2;
    log_likelihood = log_likelihood / max(log_likelihood);
    likelihood = exp(-log_likelihood);
    likelihood = reshape(likelihood,points,points);
    
    subplot(size(samples,2)+1,3,3*n+1)
    imagesc([-1 1],[-1 1],likelihood)   
    xlabel('\it w_0')
    ylabel('\it w_1')
    
    subplot(size(samples,2)+1,3,3*n+2)
    imagesc([-1 1],[-1 1],p)
    hold on
    scatter(a0,a1,'r+')
    xlabel('\it w_0')
    ylabel('\it w_1')
   
    % draw samples from posterior and show data points (x_n,t_n)
    subplot(size(samples,2)+1,3,3*n+3)
    curves = mvnrnd(m_N',S_N,10);
    scatter(x(1:N),t(1:N))
    hold on
    for j = 1:10
        plot(linspace(0,1), curves(j,1) + curves(j,2) * linspace(0,1));
    end
    hold off
    xlabel('\it x')
    ylabel('\it y')
   
end

% plot prior
m_0 = zeros(2,1);
S_0 = eye(2) / alpha;
weight_combs = [gridA(:) gridB(:)]; 
p = mvnpdf(weight_combs,m_0',S_0);
p = reshape(p,points,points);

subplot(size(samples,2)+1,3,2)
imagesc([-1 1],[-1 1],p)
hold on
scatter(a0,a1,'r+')
xlabel('\it w_0')
ylabel('\it w_1')

% draw samples from prior
subplot(size(samples,2)+1,3,3)
curves = mvnrnd(m_0',S_0,10);
hold on
for j = 1:10
    plot(linspace(0,1), curves(j,1) + curves(j,2) * linspace(0,1));
end
hold off
xlabel('\it x')
ylabel('\it y')


set(gcf,'PaperPositionMode', 'manual', ...
        'PaperUnits','centimeters', ...
        'Paperposition',[1 1 18 25])

print(gcf, '-dpdf', 'bayesian_linear.pdf','-r600');

