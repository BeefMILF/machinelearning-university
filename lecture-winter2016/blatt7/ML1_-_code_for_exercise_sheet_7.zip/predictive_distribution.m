N_max = 1000;
x = rand(N_max,1);
x_plot = linspace(0,1,1e2);
beta = 5;
f = @(x) sin(2*pi*x) - cos(pi*x);
t = f(x) + normrnd(0,1/beta,N_max,1);
alpha = 1;
s = 0.25;  % 0.2
mu = linspace(0,1,8);

Phi = ones(N_max,9);
Phi_plot = ones(1e2,9);
for i = 1:8
    Phi(:,i+1) = exp(-0.5*((x-mu(i))/s).^2);
    Phi_plot(:,i+1) = exp(-0.5*((x_plot-mu(i))/s).^2);
end

%scatter(x,t)
%xlabel('\it x')
%ylabel('\it t')

fig = figure;
samples = [1,2,4,10,100,N_max];
for k = 1:size(samples,2)
    N = samples(k);
    Phi2 = Phi(1:N,:);
    t2 = t(1:N);
    S_N = inv(alpha * eye(9) + beta * (Phi2'*Phi2));
    m_N = beta * S_N * (Phi2' * t2);
    
    y_mean = m_N' * Phi_plot';
    sigma2 = 1/beta + sum(Phi_plot .* (S_N * Phi_plot')', 2);
    upper = y_mean + sqrt(sigma2');
    lower = y_mean - sqrt(sigma2');
    
    subplot(size(samples,2),2,2*k-1)
    % plot predictive distribution
    hold on
    X=[x_plot,fliplr(x_plot)];
    Y=[lower,fliplr(upper)];
    fill(X,Y,[243 205 205]/255); 
    
    plot(x_plot, y_mean,'color',[0.8500 0.3250 0.0980])
    plot(x_plot, f(x_plot),'color',[0.4660 0.6740 0.1880])
    scatter(x(1:N),t2,20,[0 0.4470 0.7410])
    hold off
    xlabel('\it x')
    ylabel('\it t')
    ylim([-2 2])
    
    % draw samples drawn from posterior and show data points
    subplot(size(samples,2),2,2*k)
    %params = mvnrnd(m_N',S_N,10);
    
    params = mvnrnd(zeros(9,1),eye(9),10);
    params = (sqrtm(S_N)*params')' + repmat(m_N',[10 1]);
       
    scatter(x(1:N),t2,20,[0 0.4470 0.7410])
    hold on
    for j = 1:10
        y = sum(repmat(params(j,:)',1,1e2) .* Phi_plot',1);
        plot(x_plot,y)
    end
    hold off
    xlabel('\it x')
    ylabel('\it t')
    ylim([-2 2])
end

set(fig,'PaperPositionMode', 'manual', ...
    'PaperUnits','centimeters', ...
    'Paperposition',[1 1 18 25])

print(fig, '-dpdf', 'predictive_distribution.pdf','-r600');


%% example for sample from posterior distribution

N = 10;
x = rand(N,1);
x_plot = linspace(0,1,1e2);
beta = 5;
f = @(x) sin(2*pi*x) - cos(pi*x);
t = f(x) + normrnd(0,1/beta,N,1);
alpha = 1;
s = 0.25;  % 0.2
mu = linspace(0,1,8);

Phi = ones(N,9);
Phi_plot = ones(1e2,9);
for i = 1:8
    Phi(:,i+1) = exp(-0.5*((x-mu(i))/s).^2);
    Phi_plot(:,i+1) = exp(-0.5*((x_plot-mu(i))/s).^2);
end

S_N = inv(alpha * eye(9) + beta * (Phi'*Phi));
m_N = beta * S_N * (Phi' * t);

params = mvnrnd(m_N',S_N,1);
y = sum(repmat(params',1,1e2) .* Phi_plot',1);
figure
plot(x_plot,f(x_plot),'color',[0.4660 0.6740 0.1880],'linewidth',2)
hold on
plot(x_plot,y,'color',[0.6350    0.0780    0.1840],'linewidth',2)
for i = 1:9
    plot(x_plot,params(i)*Phi_plot(:,i),'color',[0.7 0.7 0.7])
end
scatter(x,t,20,[0 0.4470 0.7410])
xlabel('\it x')
ylabel('\it t')
legend('\it f','\it y','\phi_i')



